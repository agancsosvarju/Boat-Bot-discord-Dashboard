/**
 * @file copyright.js
 * @author Sanjay Sunil
 * @license GPL-3.0
 */

$('.000').replaceWith('Copyright © 2022');
$('.001').replaceWith('Sanjay Sunil');
$('.002').replaceWith('All rights reserved.');
